#include <glad/glad.h>
#include <GLFW/glfw3.h>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <iostream>
#include <string>

#define TINYOBJLOADER_IMPLEMENTATION
#include "tiny_obj_loader.h"


//modifier for x position
float x_mod = 0.0000f;
float y_mod = 0.0000f;
float z_mod = 0.0000f;

void Key_Callback(GLFWwindow* window, //pointer to the window
    int key, //keycode of the press
    int scancode, //physical position of the press
    int action, //either press/release
    int mods) //which modifier keys is held down
    {
        if(key == GLFW_KEY_D /* && action == GLFW_PRESS */ )
            //move to right
            std::cout << "D";
            x_mod += 0.1f;

        if (key == GLFW_KEY_A /* && action == GLFW_PRESS */)
            //move to right
            std::cout << "A";
            x_mod -= 0.1f;

        if (key == GLFW_KEY_W /* && action == GLFW_PRESS */)
            //move forward
            std::cout << "W";
            z_mod += 0.1f;
/*
        if (key == GLFW_KEY_S 
        // && action == GLFW_PRESS )
        //move backward
            y_mod -= 0.1f;
 */
    }
int main(void)
{
    //load the shader file into ta string stream
    std::fstream vertSrc("Shaders/sample.vert");
    std::stringstream vertBuff;

    //add the fom;e strea, tptneh string stream
    vertBuff << vertSrc.rdbuf();

    //convers the stream to a character arrray
    std::string vertS = vertBuff.str();
    const char* v = vertS.c_str();

    //load the shader file into ta string stream
    std::fstream fragSrc("Shaders/sample.frag");
    std::stringstream fragBuff;

    //add the fom;e strea, tptneh string stream
    fragBuff << fragSrc.rdbuf();

    //convers the stream to a character arrray
    std::string fragS = fragBuff.str();
    const char* f = fragS.c_str();

    GLFWwindow* window;

    float window_width = 1600;
    float window_height = 1600;


    /* Initialize the library */
    if (!glfwInit())
        return -1;

    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(1600, 1600, "Matthew Jayd Baldonado", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    /* Make the window's context current */
    glfwMakeContextCurrent(window);
    gladLoadGL();

    //set the calllback function to the window
    glfwSetKeyCallback(window, Key_Callback);

    //creat a vertex shader
    GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
    //assign the source to the vertex shader
    glShaderSource(vertexShader, 1, &v , NULL);
    //compile the vertex shader
    glCompileShader(vertexShader);

    //creat a fragment shader
    GLuint fragShader = glCreateShader(GL_FRAGMENT_SHADER);
    //assign the source to the framgment shader
    glShaderSource(fragShader, 1, &f, NULL);
    //compile the fragment shader
    glCompileShader(fragShader);

    //create tge shader  program
    GLuint shaderProg = glCreateProgram();

    //attach the compiled vertex shader
    glAttachShader(shaderProg, vertexShader);

    //attach the compoled framgnet chsader
    glAttachShader(shaderProg, fragShader);

    //finalize the compilation process
    glLinkProgram(shaderProg);

    std::string path = "3D/bunny.obj";
    std::vector<tinyobj::shape_t> shapes;
    std::vector<tinyobj::material_t> material;
    std::string warning, error;

    tinyobj::attrib_t attributes;

    bool success = tinyobj::LoadObj(
        &attributes,
        &shapes,
        &material,
        &warning,
        &error,
        path.c_str()
    );

    std::vector<GLuint> mesh_indices;
    for (int i = 0; i < shapes[0].mesh.indices.size(); i++)
    {
        mesh_indices.push_back(shapes[0].mesh.indices[i].vertex_index);
    }

    GLfloat vertices[]
    {
        //x  //y   //z
        0.f, 0.5f, 0.f, //0
        -0.5f, -0.5f, 0.f, //1
        0.5f, -0.5f, 0.f //2

    };

    GLuint indices[]
    {
        0,1,2
    };

    //Create VAO,VBO,EBO Variables
    GLuint VAO, VBO, EBO;

    //Initialize VAO and VBO
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    //Currently Editing VAO = null
    glBindVertexArray(VAO);
    //Currently Editing VAO = VAO
    // 
    //Currently Editing VBO = null
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    //Currently Editing VBO = VBO
    //VAO <-VBO

    glBufferData(
        GL_ARRAY_BUFFER,
        sizeof(GL_FLOAT) * attributes.vertices.size() /*Size of buffer in bytes*/,
        attributes.vertices.data() /*Array*/,
        GL_STATIC_DRAW
    );

    glVertexAttribPointer(0, 3 /*x y z*/,
        GL_FLOAT,
        GL_FALSE, 3 * sizeof(float),
        (void*)0);

    //Currently Editing VBO = VBO
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    //Currently Editing VBO = EBO
    glBufferData(
        GL_ELEMENT_ARRAY_BUFFER,
        sizeof(GLuint) * mesh_indices.size(),
        mesh_indices.data(),
        GL_STATIC_DRAW
    );

    glEnableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

    glm::mat4 identity_matrix = glm::mat4(1.0f);
    float x = 0, y = 0, z = -5.0;
    float scale_x = 1, scale_y = 1, scale_z = 1;
    float axis_x = 0, axis_y = 1,axis_z = 0;
    float theta = 90.0;

/*  //Create projection matrix
    glm::mat4 projectionMatrix = glm::ortho(-2.f, //L
        2.f,  //R
        -2.f, //B
        2.f,  //T
        -1.f, //Znear
        1.f); //Zfar
*/

    glm::mat4 projectionMatrix = glm::perspective(glm::radians(60.f), // FOV
        window_height / window_width, // Aspect Ratio
        0.1f, // ZNear > 0
        100.f); // ZFar

    /* Loop until the user closes the window */
    while (!glfwWindowShouldClose(window))
    {
        /* Render here */
        glClear(GL_COLOR_BUFFER_BIT);

        theta += 0.2;
        //scale_x += 0.0001, scale_y += 0.0001, scale_z += 0.0001;



        //strat with the trasformation matrix
        glm::mat4 transformation_matrix = glm::translate(
            identity_matrix,
            glm::vec3(x, y, z)
        );

        //multiply the resulting matrix with the scale matrix

        transformation_matrix = glm::scale(
            transformation_matrix,
            glm::vec3(scale_x, scale_y, scale_z)
        );

        //finally multiply it with the roratiton matrix
        transformation_matrix = glm::rotate(
            transformation_matrix,
            glm::radians(theta),
            glm::normalize(glm::vec3(axis_x, axis_y, axis_z)));

            //get location of the transofrm varioable in the shader
            unsigned int transformLoc = glGetUniformLocation(shaderProg, "transform");

        glUniformMatrix4fv(transformLoc, 1, GL_FALSE, glm::value_ptr(transformation_matrix));

        

        

        //tell open GL to use this shader
        // //for the VAO/s bellow
        glUseProgram(shaderProg);
        glBindVertexArray(VAO);

        //Bind The VAO to prep it for drawing
        glBindVertexArray(VAO);
        //Draw the triangle
        //glDrawArrays(GL_TRIANGLES, 0 , 3);
        glDrawElements(GL_TRIANGLES, mesh_indices.size(), GL_UNSIGNED_INT, 0);

        /* Swap front and back buffers */
        glfwSwapBuffers(window);

        /* Poll for and process events */
        glfwPollEvents();
    }
    //Cleanup
    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &EBO);

    glfwTerminate();
    return 0;
}